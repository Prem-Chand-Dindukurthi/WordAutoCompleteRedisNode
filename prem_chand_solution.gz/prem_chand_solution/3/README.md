start redis server:
    -redis-server
run redis-cli and we can check if values are correctly stored:
    -redis-cli
run app.js
    - node app.js

endpointsToHit:
    - http://localhost:3000/add_word?word=foo
    - http://localhost:3000/autocomplete?query=fo


#This application is working, but however I am not able to execute them from docker
