app.js uses express for routing
index.js contains all the routing structure like which handler to use for which end point
