const router = require("express").Router();

router.use("/add_word", require("./wordAddionHandler"));
router.use("/autocomplete", require("./autoCompleteHandler"));

module.exports = router;

