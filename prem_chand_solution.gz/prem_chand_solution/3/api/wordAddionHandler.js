const redis = require('redis');
const router = require("express").Router()

const insertInRedis = async (word) => {
    console.log("inserting in redis")
    redisClient = redis.createClient();
    console.log("created redis client")
    await redisClient.connect();
    console.log("redis client is now connected")

    redisClient.on("error", function (err) {
        console.log("Error " + err);
    });

    args = [{"score":0, "value":word+"*"}]

    for (let i=0 ; i<word.length; i++){
        wordToInsert = word.substr(0,i+1)
        console.log(wordToInsert)
        pp = {"score":0, "value":wordToInsert}
        args.push(pp)
    }
    console.log(args)

    // args = [{"score":0, "value":"foobar"}, {"score":0, "value":"foo"}]
    redisClient.ZADD("word_dict", args)
    // console.log( await redisClient.ZRANGE("word_dict",0,-1))
    // console.log( await redisClient.ZRANK("word_dict", "foobar" ))

    redisClient.quit()
}

const addWordFunction = (req, res)=>{
    req = req.query;
    console.log(req);
    console.log(typeof(req));

    const {word} = req
    console.log(word);
    console.log(typeof(word))
    
    insertInRedis(word)
    response = "OK"
    res.status(200).json({response});
};


router.get(
    "/",
    addWordFunction
);

module.exports = router;

