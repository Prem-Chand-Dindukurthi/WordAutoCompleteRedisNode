const redis = require('redis');
const router = require("express").Router()

const fetchFromRedis = async (query) => {
    redisClient = redis.createClient();
    console.log("created redis client")
    await redisClient.connect();
    console.log("redis client is now connected")

    redisClient.on("error", function (err) {
        console.log("Error " + err);
    });
    
    // args = [{"score":0, "value":"foobar"}, {"score":0, "value":"foo"}]
    // redisClient.ZADD("word_dict", args)
    rankOfWord = await redisClient.ZRANK("word_dict", query )
    console.log( rankOfWord )
    
    listOfWords = await redisClient.ZRANGE("word_dict",rankOfWord + 1 ,-1) 

    let finalListToReturn = []

    for (index in listOfWords)
    {
        word = listOfWords[index]
        if (word.includes("*")){
            finalListToReturn.push(word.replace("*",""))
        }
        if (word.length < query.length){
            break;
        }
    }
    console.log("finalListToReturn:")
    console.log(finalListToReturn)
    await redisClient.quit()
    return finalListToReturn
}

const autoCompleteFunction = async (req, res)=>{
    req = req.query;
    console.log(req);
    console.log(typeof(req));

    const {query} = req
    console.log(query);
    console.log(typeof(query))
    
    possibleWords =  await fetchFromRedis(query)
    
    console.log("possibleWords: ")
    console.log(possibleWords)
    res.status(200).json({possibleWords});
};


router.get(
    "/",
    autoCompleteFunction
);

module.exports = router;

