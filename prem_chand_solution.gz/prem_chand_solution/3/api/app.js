const express = require('express');

const app = express();
app.use(express.json())

const portNumber = 3000;
app.use(require("./index"));


app.listen(
    portNumber,
    () => {
        console.log("started to listen to port " + portNumber);
    }
)

module.exports = express;

