sed -e 's/\([a-z]*\) \1/(\1)/g' -e 's/()/ /g' -e 's/[()]//g' 

In first sed execution: 
--[a-z]* is a regex which would find any word
--now put them in parenthesis in order to store and we can used the remembered patten as "\1"
--now regex followed by a space and followed by "\1" would match a pattern of consecutive repeated words which is repeated twice
--so if repeated word is PREMCHAND, then it is replaced with (PREMCHAND) with parenthesis
--along with that spaces are replaced with emty parenthesis

In second sed execution:
--replace empty parenthesis with space
--repeated word (PREMCHAND) is not changed

In third sed execution:
--remove parenthesis brackets

It then outputs the solution to stdout


##However the above command would not work if there are any parenthesis involved in the input text. The work around would be converting the parenthesis to some pattern first and then restore the pattern back to parenthesis
